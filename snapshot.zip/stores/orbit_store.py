from __future__ import annotations

from typing import Any

import numpy as np
import numpy.typing as npt

from ecs.soa_store import SoAStore
from components.orbit import Orbit


class OrbitStore(SoAStore):
    def __init__(self, entity_capacity: int, initial_dense_capacity: int = 1024) -> None:
        super().__init__(entity_capacity=entity_capacity, initial_dense_capacity=initial_dense_capacity)

        cap = int(initial_dense_capacity)
        if cap <= 0:
            cap = 1

        self.ox: npt.NDArray[np.float32] = np.zeros(cap, dtype=np.float32)
        self.oy: npt.NDArray[np.float32] = np.zeros(cap, dtype=np.float32)
        self.oz: npt.NDArray[np.float32] = np.zeros(cap, dtype=np.float32)

        self.ax: npt.NDArray[np.float32] = np.zeros(cap, dtype=np.float32)
        self.ay: npt.NDArray[np.float32] = np.zeros(cap, dtype=np.float32)
        self.az: npt.NDArray[np.float32] = np.zeros(cap, dtype=np.float32)

    def _ensure_dense_capacity(self, new_dense_capacity: int) -> None:
        cur = int(self.vx.shape[0])
        if new_dense_capacity <= cur:
            return
        super()._ensure_dense_capacity(new_dense_capacity)

        self.ox = np.resize(self.ox, new_dense_capacity).astype(np.float32, copy=False)
        self.oy = np.resize(self.oy, new_dense_capacity).astype(np.float32, copy=False)
        self.oz = np.resize(self.oz, new_dense_capacity).astype(np.float32, copy=False)
        
        self.ax = np.resize(self.ax, new_dense_capacity).astype(np.float32, copy=False)
        self.ay = np.resize(self.ay, new_dense_capacity).astype(np.float32, copy=False)
        self.az = np.resize(self.az, new_dense_capacity).astype(np.float32, copy=False)

    def _on_add_dense(self, dense_i: int, component: Any) -> None:
        if not isinstance(component, Orbit):
            raise TypeError(f'OrbitStore expected Orbit, got {type(component)}')

        o = component.origin
        a = component.angular
        if o.shape != (3,):
            raise ValueError('Orbit.origin must be shape (3,) float32 array')
        
        if a.shape != (3,):
            raise ValueError('Orbit.angular must be shape (3,) float32 array')

        self.ox[dense_i] = np.float32(o[0])
        self.oy[dense_i] = np.float32(o[1])
        self.oz[dense_i] = np.float32(o[2])

        self.ax[dense_i] = np.float32(a[0])
        self.ay[dense_i] = np.float32(a[1])
        self.az[dense_i] = np.float32(a[2])

    def _on_move_dense(self, dst_i: int, src_i: int) -> None:
        self.ox[dst_i] = self.ox[src_i]
        self.oy[dst_i] = self.oy[src_i]
        self.oz[dst_i] = self.oz[src_i]
        
        self.ax[dst_i] = self.ax[src_i]
        self.ay[dst_i] = self.ay[src_i]
        self.az[dst_i] = self.az[src_i]

    def _on_clear_dense(self, dense_i: int) -> None:
        self.ox[dense_i] = 0.0
        self.oy[dense_i] = 0.0
        self.oz[dense_i] = 0.0
        
        self.ax[dense_i] = 0.0
        self.ay[dense_i] = 0.0
        self.az[dense_i] = 0.0