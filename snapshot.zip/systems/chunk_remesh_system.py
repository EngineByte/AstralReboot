from __future__ import annotations

import numpy as np

from ecs.query import Query
from ecs.world import ECSWorld
from components.chunk import Chunk
from components.mesh import Mesh
from components.transform import Transform
from components.tags import DirtyRemesh

from resources.voxels.voxel_pool import VoxelPool
from renderer.mesh_pool import MeshPool
from resources.voxels.meshing import build_surface_mesh_from_voxels
def get_model_matrix(pos: tuple[float, float, float], rot: tuple[float, float, float]) -> np.ndarray[np.float32]:
    pmtx = np.identity(4, dtype=np.float32)
    rmtx = np.identity(4, dtype=np.float32)

    pmtx[:3, 3] = pos
    y, p, r = rot
    yaw, pitch, roll = np.radians(y), np.radians(p), np.radians(r)

    cy, sy = np.cos(yaw), np.sin(yaw)
    cp, sp = np.cos(pitch), np.sin(pitch)
    cr, sr = np.cos(roll), np.sin(roll)

    ymtx = np.identity(4, dtype=np.float32)
    ymtx[0, 0], ymtx[2, 2] = cy, cy
    ymtx[0, 2], ymtx[2, 0] = sy, -sy

    pmtx = np.identity(4, dtype=np.float32)
    pmtx[1, 1], pmtx[2, 2] = cp, cp
    pmtx[1, 2], pmtx[2, 1] = -sp, sp
    
    rmtx = np.identity(4, dtype=np.float32)
    rmtx[0, 0], rmtx[1, 1] = cr, cr
    rmtx[0, 1], rmtx[1, 0] = sr, -sr

    model = pmtx @ ymtx @ pmtx @ rmtx

    return model


def system_chunk_remesh(world: 'ECSWorld', dt: float) -> None:
    chunks = world.store(Chunk)    
    meshes = world.store(Mesh)
    tr = world.store(Transform)

    voxel_pool = world.resources.get(VoxelPool)
    mesh_pool = world.resources.get(MeshPool)

    for eid, i_tr, i_chunk, i_mesh in Query(world, (Transform, Chunk, Mesh, DirtyRemesh)):
        pos = (tr.px[i_tr], tr.pz[i_tr], tr.pz[i_tr])
        rot = (tr.yaw[i_tr], tr.pitch[i_tr], tr.roll[i_tr])
        model = get_model_matrix(pos, rot)
        size = int(chunks.size[i_chunk])
        handle = int(chunks.voxel_handle[i_chunk])

        block = voxel_pool.block(handle)
        verts, indices = build_surface_mesh_from_voxels(model, block.data, size=size, method='greedy')

        cur_mesh_id = int(meshes.mesh_id[i_mesh])
        new_mesh_id = mesh_pool.upload_or_replace(cur_mesh_id, verts, indices)
        meshes.mesh_id[i_mesh] = new_mesh_id

        world.defer_remove_tag(eid, DirtyRemesh)