from __future__ import annotations
from typing import TYPE_CHECKING
import numpy as np

from ecs.query import Query
from components.transform import Transform
from components.velocity import Velocity
from components.orbit import Orbit

if TYPE_CHECKING:
    from ecs.world import ECSWorld


def system_movement(world: 'ECSWorld', dt: float) -> None:
    tr = world.store(Transform)
    vel = world.store(Velocity)
    orb = world.store(Orbit)
    dt32 = np.float32(dt)

    for eid, i_vel, i_orb in Query(world, (Velocity, Orbit)):
        yaw = np.radians(orb.ay[i_orb] * dt32)
        pitch = np.radians(orb.ax[i_orb] * dt32)
        roll = np.radians(orb.az[i_orb] * dt32)
        cy, sy = np.cos(yaw), np.sin(yaw)
        cp, sp = np.cos(pitch), np.sin(pitch)
        cr, sr = np.cos(roll), np.sin(roll)
        ymtx = np.identity(4, dtype=np.float32)
        ymtx[0, 0], ymtx[2, 2] = cy, cy
        ymtx[0, 2], ymtx[0, 2] = sy, -sy

        pmtx = np.identity(4, dtype=np.float32)
        pmtx[1, 1], pmtx[2, 2] = cp, cp
        pmtx[1, 2], pmtx[2, 1] = -sp, sp

        rmtx = np.identity(4, dtype=np.float32)
        rmtx[0, 0], rmtx[1, 1] = cr, cr
        rmtx[0, 1], rmtx[1, 0] = sr, -sr

        rot = ymtx @ pmtx @ rmtx

        velocity = np.array([vel.vx[i_vel], vel.vy[i_vel], vel.vz[i_vel], 1.0])

        vel_after = rot @ velocity

        vel.vx[i_vel] = vel_after[0]
        vel.vy[i_vel] = vel_after[1]
        vel.vz[i_vel] = vel_after[2]


    for eid, i_tr, i_vel in Query(world, (Transform, Velocity)):
        tr.px[i_tr] += vel.vx[i_vel] * dt32
        tr.py[i_tr] += vel.vy[i_vel] * dt32
        tr.pz[i_tr] += vel.vz[i_vel] * dt32

        tr.yaw[i_tr] += vel.ay[i_vel] * dt32
        tr.pitch[i_tr] += vel.ax[i_vel] * dt32
        tr.roll[i_tr] += vel.az[i_vel] * dt32
        
