from __future__ import annotations

import numpy as np

from ecs.world import ECSWorld
from ecs.system_spec import SystemSpec

from components.transform import Transform
from components.velocity import Velocity
from components.camera import Camera
from components.camera_matrices import CameraMatrices
from components.tags import DirtyMatrices

from systems.movement_system import system_movement
from systems.camera_system import system_update_camera_matrices
from systems.render_system import system_render

from renderer.renderer import Renderer


def setup_game_world(world: ECSWorld) -> None:
    renderer = Renderer()
    world.resources.add(Renderer, renderer)

    player = world.create_entity()

    world.add_component(player, Transform(
        position=np.array([0.0, 0.0, -5.0], dtype=np.float32),
        rotation=np.array([0.0, 0.0, 0.0], dtype=np.float32),
        scale=np.array([1.0, 1.0, 1.0], dtype=np.float32),
    ))

    world.add_component(player, Velocity(
        linear=np.zeros(3, dtype=np.float32)
    ))

    camera = world.create_entity()

    world.add_component(camera, Transform(
        position=np.array([0.0, 1.8, -5.0], dtype=np.float32),
        rotation=np.array([0.0, 0.0, 0.0], dtype=np.float32),
        scale=np.array([1.0, 1.0, 1.0], dtype=np.float32),
    ))

    world.add_component(camera, Camera(
        fov=75.0,
        near=0.1,
        far=5000.0,
        aspect=1280.0 / 720.0,
    ))

    def construct_view_matrix(y, p, r, px, py, pz):
        yaw=np.radians(y+180.0)
        pitch=np.radians(p)
        roll=np.radians(r)

        cy, sy = np.cos(yaw), np.sin(yaw)
        cp, sp = np.cos(pitch), np.sin(pitch)
        cr, sr = np.cos(roll), np.sin(roll)
        
        mtx_yaw = np.identity(4, dtype=np.float32)
        mtx_pitch = np.identity(4, dtype=np.float32)
        mtx_roll = np.identity(4, dtype=np.float32)

        mtx_yaw[0, 0], mtx_yaw[2, 2] = cy, cy
        mtx_yaw[0, 2], mtx_yaw[2, 0] = -sy, sy
        
        mtx_pitch[1, 1], mtx_pitch[2, 2] = cp, cp
        mtx_pitch[1, 2], mtx_pitch[2, 1] = sp, -sp
        
        mtx_roll[0, 0], mtx_roll[1, 1] = cr, cr
        mtx_roll[0, 1], mtx_roll[1, 0] = -sr, sr

        mtx_pos = np.identity(4, dtype=np.float32)
        mtx_pos[:3, 3] = (-px, -py, -pz)
        mtx_rot = mtx_roll @ mtx_pitch @ mtx_yaw
        view = mtx_rot @ mtx_pos

        return view
        
    def construct_proj_matrix(fov, zn, zf, aspect):
        proj = np.identity(4, dtype=np.float32)

        f_factor = 1 / np.tan(0.5 * np.radians(fov))
        z_factor = (zn + zf) / (zf - zn)
        z_offset = 2.0 * zn * zf / (zn - zf)

        proj[0, 0] = f_factor / aspect
        proj[1, 1] = f_factor
        proj[2, 2] = z_factor
        proj[2, 3] = z_offset
        proj[3, 2] = -1.0

        return proj

    view = construct_view_matrix(
        y=0.0, 
        p=0.0, 
        r=0.0, 
        px=0.0, 
        py=1.8, 
        pz=-5.0
    )

    proj = construct_proj_matrix(
        fov=60.0, 
        zn=0.1, 
        zf=5000.0, 
        aspect=1280.0 / 720.0
    )

    world.add_component(camera, CameraMatrices(
        view=view,
        projection=proj,
    ))

    world.add_tag(camera, DirtyMatrices)

    world.scheduler.add_system(
        SystemSpec(
            func=system_movement,
            phase="update",
        )
    )

    world.scheduler.add_system(
        SystemSpec(
            func=system_update_camera_matrices,
            phase="late_update",
        )
    )

    world.scheduler.add_system(
        SystemSpec(
            func=system_render,
            phase="render",
        )
    )