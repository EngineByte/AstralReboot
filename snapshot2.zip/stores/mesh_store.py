from typing import Any
import numpy as np
import numpy.typing as npt

from ecs.soa_store import SoAStore
from components.mesh import Mesh


class MeshStore(SoAStore):
    def __init__(self, entity_capacity: int, initial_dense_capacity: int = 1024) -> None:
        super().__init__(entity_capacity=entity_capacity, initial_dense_capacity=initial_dense_capacity)

        cap = int(entity_capacity)
        if cap <= 0:
            cap = 1

        self.data: npt.NDArray[np.float32] = np.zeros(cap, dtype=np.float32)

    def _ensure_dense_capacity(self, new_dense_capacity: int) -> None:
        cur = int(self.data.shape[0])
        if new_dense_capacity <= cur:
            return
        
        super()._ensure_dense_capacity(new_dense_capacity)

        self.data = np.resize(self.data, new_dense_capacity).astype(np.float32, copy=False)

    def _on_add_dense(self, dense_i: int, component: Any) -> None:
        if not isinstance(component, Mesh):
            raise TypeError(f"VelocityStore expected Mesh, got {type(component)}")
        
        self.data[dense_i] = component.data
        
    def _on_move_dense(self, dst_i: int, src_i: int) -> None:
        self.data[dst_i] = self.data[src_i]

    def _on_clear_dense(self, dense_i: int) -> None:
        self.data[dense_i] = 0.0